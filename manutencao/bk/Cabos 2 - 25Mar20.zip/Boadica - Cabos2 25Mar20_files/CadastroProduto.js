﻿
$(document).ready(function () {

    var tabela;
    var alterados = [];
    var compacta = false;

    if (typeof temAviso != 'undefined')
        $('#modalAviso').modal('show');

    function contaAtivos() {
        var ativos = tabela.$('input[type=checkbox]:checked').length;
        $('#conta-ativos').text(ativos);

        var alteracoes = Object.keys(alterados).length;
        $('#conta-alteracoes, #toolbarRevenda span').text(alteracoes);

        $('#btn-atualizar').prop('disabled', (alteracoes < 1));
        if (alteracoes < 1)
            $('#toolbarRevenda').hide();
        else
            $('#toolbarRevenda').show();
        return ativos;
    }

    $('#ck-all').click(function (e) {
        var rows = tabela.rows().nodes();

        if (rows.length > qtdMax) {
            if (!confirm('Esta operação não poderá ser realizada completamente pois existem mais produtos cadastrados que o total disponível para sua loja. Confirma?')) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        }
        else if (!confirm('Isso irá afetar todos os seus produtos, confirma?')) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }

        var ativos = contaAtivos();

        tabela.$('input[type="checkbox"]').each(function () {
            if (!$(this).prop('checked')) {
                if (ativos < qtdMax) {
                    codProdLoja = $(this).data('id');
                    $(this).prop('checked', true);
                    alterados['prod' + codProdLoja] = codProdLoja;
                    ativos++;
                }
            }
        });

        contaAtivos();

        e.preventDefault();
        e.stopPropagation();
        return false;
    });


    $('#unck-all').click(function (e) {
        if (!confirm('Isso irá afetar todos os seus produtos, confirma?')) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }

        tabela.$('input[type="checkbox"]').each(function () {
            if ($(this).prop('checked')) {
                codProdLoja = $(this).data('id');
                $(this).prop('checked', false);
                alterados['prod' + codProdLoja] = codProdLoja;
            }
        });

        contaAtivos();

        e.preventDefault();
        e.stopPropagation();
        return false;
    });

    $('body').on('change', 'input[type=checkbox][name=ativo]', function (e) {
        var ativos = contaAtivos();

        if ($(this).prop('checked') && ativos > qtdMax) {
            $(this).prop('checked', false).fadeOut(300).fadeIn(300);
            contaAtivos();
            return false;
        }

        var id = $(this).data('id');
        alterados['prod' + id] = id;
        contaAtivos();
    });

    $('body').on('click', '.modal-foto', function () {
        var href = $(this).data('href');
        var header = $(this).data('header');
        $('#foto-modal').prop('src', 'https://boadica-static.s3.amazonaws.com/prod/imagesprod/' + href);
        $('#foto-header').text(header);
        $('#modalFoto').modal('show');
        return false;
    });

    $('body').on('keydown change', '[data-id]', function () {
        if (!$(this).is('input[type=checkbox][name=ativo]')) {
            var id = $(this).data('id');
            alterados['prod' + id] = id;
            contaAtivos();
        }
    });


    /* Create an array with the values of all the input boxes in a column */
    $.fn.dataTable.ext.order['dom-text'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val();
        });
    }

    /* Create an array with the values of all the input boxes in a column, parsed as numbers */
    $.fn.dataTable.ext.order['dom-text-numeric'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val() * 1;
        });
    }

    /* Create an array with the values of all the input boxes in a column, parsed as numbers */
    $.fn.dataTable.ext.order['dom-text-preco'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return parseFloat($('input', td).val().replace('.', '').replace(',', '.'));
        });
    }

    /* Create an array with the values of all the select options in a column */
    $.fn.dataTable.ext.order['dom-select'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('select', td).val();
        });
    }

    /* Create an array with the values of all the checkboxes in a column */
    $.fn.dataTable.ext.order['dom-checkbox'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).prop('checked') ? '1' : '0';
        });
    }

    // Verifica se possui tamanho salvo
    var myLength = readCookie('RevendaCadastroProdutosLength');
    if (myLength == null)
        myLength = -1;
    else
        myLength = parseInt(myLength);

    compacta = (readCookie('RevendaCadastroProdutosCompacta') != null);
    if (compacta)
        $('#icon-condensar').removeClass('fa-compress').addClass('fa-expand').prop('title', 'Expandir especificação');

    tabela = $('#tabela-produtos').DataTable({
        ajax: function (data, callback, settings) {
            $.ajax({
                url: 'getprodutos',
                type: 'POST',
                data: data,
                success: function (data) {
                    callback(data);
                    contaAtivos();
                }
            });
        },
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'Todos']],
        pageLength: myLength,
        responsive: true,
        order: [[0, 'asc'], [1, 'asc']],
        initCompete: function () {
            contaAtivos();
        },
        drawCallback: function (settings) {
            $('.money').css('text-align', 'right').maskMoney({ thousands: '', decimal: ',', allowZero: true });
        },
        stateSave: true,
        stateSaveCallback: function (settings, data) {
            setCookie('RevendaCadastroProdutosLength', data.length, 365);
        },
        stateLoadCallback: function (settings) {
            return null;
        },
        language: {
            'sEmptyTable': 'Nenhum produto encontrado',
            'sInfo': 'Mostrando de _START_ até _END_ de _TOTAL_ produtos cadastrados',
            'sInfoEmpty': 'Mostrando 0 até 0 de 0 produtos cadastrados',
            'sInfoFiltered': '(Filtrados de _MAX_ produtos cadastrados)',
            'sInfoPostFix': '',
            'sInfoThousands': '.',
            'sLengthMenu': '_MENU_ produtos por página',
            'sLoadingRecords': 'Carregando...',
            'sProcessing': 'Processando...',
            'sZeroRecords': 'Nenhum produto encontrado',
            'sSearch': 'Pesquisar em Fabricante, Modelo ou Especificação',
            'oPaginate': {
                'sNext': 'Próximo',
                'sPrevious': 'Anterior',
                'sFirst': 'Primeiro',
                'sLast': 'Último'
            },
            'oAria': {
                'sSortAscending': ': Ordenar colunas de forma ascendente',
                'sSortDescending': ': Ordenar colunas de forma descendente'
            }
        },
        columns: [
            { data: 'fabricante' },
            {
                data: 'modelo',
                render: function (data, type, row) {
                    var html = row.modelo;
                    if (row.foto != '' && row.foto != null) {
                        html += '<br/>' +
                            '<a href="#" data-href="' + row.foto + '" data-header="' + row.fabricante + ' - ' + row.modelo + '" class="modal-foto"><i class="fa fa-camera" aria-hidden="true"></i></a>';
                    };
                    return html;
                },
            },
            {
                data: 'especificacao',
                render: function (data, type, row) {
                    var html = '<span class="especificacao ' + (compacta ? 'compacta' : 'expandida') + '">' + row.especificacao + '</span>';
                    return html;
                }
            },
            {
                data: 'emBox',
                render: function (data, type, row) {
                    var html = '';
                    html = '<select name="oem" class="form-control" data-id="' + row.codProdLoja + '" style="width:100px;">' +
                        '<option value=" ">Não especificado</option>';
                    if (row.aceitaOem) {
                        if (row.emBox == 'O')
                            html += '<option value="O" selected>OEM</option>';
                        else
                            html += '<option value="O">OEM</option>';
                    }
                    if (row.emBox == 'B')
                        html += '<option value="B" selected>BOX</option>';
                    else
                        html += '<option value="B">BOX</option>';
                    html += '</select>';
                    return html;
                },
                orderDataType: 'dom-select'
            },
            {
                data: 'origem',
                render: function (data, type, row) {
                    var html = '';
                    if (row.aceitaImportado) {
                        html = '<select name="importado_nacional" class="form-control" data-id="' + row.codProdLoja + '" style="width:100px;">' +
                            '<option value=" " selected>Não especificado</option>';
                        if (row.origem == 'I')
                            html += '<option value="I" selected>Importado</option>';
                        else
                            html += '<option value="I">Importado</option>';
                        if (row.origem == 'N')
                            html += '<option value="N" selected>Nacional</option>';
                        else
                            html += '<option value="N">Nacional</option>';
                        html += '</select>';
                    }
                    else {
                        html = '<select name="importado_nacional" class="form-control" style="width:100px;" disabled>' +
                            '<option value=" " selected>Não especificado</option>' +
                            '</select>';
                    }
                    return html;
                },
                orderDataType: 'dom-select'
            },
            {
                data: 'preco',
                render: function (data, type, row) {
                    if (row.alteracoes >= maxAlteracoes)
                        return '<input style="text-align:right;width:100px;" type="text" name="preco" class="form-control" value="' + row.preco + '" data-id="' + row.codProdLoja + '" data-preco="' + row.preco + '" size="2" disabled title="Atingido o número máximo de alterações diárias de preço para este produto">';

                    return '<input style="text-align:right;width:100px;" type="text" name="preco" class="form-control money" value="' + row.preco + '" data-id="' + row.codProdLoja + '" data-preco="' + row.preco + '" size="2">';
                },
                orderDataType: 'dom-text-preco'
            },
            {
                data: 'ativo',
                render: function (data, type, row) {
                    if (row.ativo)
                        return '<input type="checkbox" name="ativo" data-id="' + row.codProdLoja + '" value="1" checked />';
                    return '<input type="checkbox" name="ativo" data-id="' + row.codProdLoja + '" value="1" />';
                },
                orderDataType: 'dom-checkbox'
            },
        ],
    });

    $('#btn-atualizar, #btn-atualizar-ofertas-toolbar').click(function () {
        var alteracoes = Object.keys(alterados).length;
        $('#span-atualizar-ofertas').text(alteracoes);

        if (alteracoes > 10)
            $('#demorar-atualizar-ofertas').removeClass('hidden');
        else
            $('#demorar-atualizar-ofertas').addClass('hidden');

        $('#modalAtualizando').modal({ backdrop: 'static', keyboard: false });

        // Para dar tempo da modal aparecer
        setTimeout(function () {
            var data = [];
            $.each(tabela.rows().data(), function (i, o) {
                if (alterados['prod' + o.codProdLoja] !== undefined) {
                    var row = tabela.$('[data-id=' + o.codProdLoja + ']');

                    var obj = {};
                    obj.codProdLoja = o.codProdLoja;
                    obj.oem = row.filter('select[name=oem]').val();
                    obj.importado_nacional = row.filter('select[name=importado_nacional]').val();
                    obj.preco = parseFloat(row.filter('input[type=text][name=preco]').val().replace('.', '').replace(',', '.'));
                    obj.ativo = row.filter('input[type=checkbox][name=ativo]').prop('checked');

                    if (obj.importado_nacional == undefined)
                        obj.importado_nacional = null;

                    data.push(obj);
                }
            });

            if (data.length < 1) {
                $('#modalAtualizando').modal('toggle');
                alert('Nenhuma alteração a ser efetuada');
                return;
            }

            $.ajax({
                type: 'POST',
                url: 'atualizar',
                data: JSON.stringify(data),
                contentType: 'application/json; charset=utf-8',
                success: function (status) {
                    $('#modalAtualizando').modal('toggle');
                    if (status != 'ok')
                        alert(status);
                    window.location.reload();
                },
                failure: function (errMsg) {
                    $('#modalAtualizando').modal('toggle');
                    alert(errMsg);
                    window.location.reload();
                }
            });
        }, 1000);
        return false;
    });

    $('#btn-adicionar-produtos').click(function () {
        window.location.href = 'incluirproduto';
    });

    $('#btn-limpar-desativados').click(function () {
        $.getJSON('desativados', function (lista) {
            // Pega os produtos destivados da lista
            var html = '';
            $.each(lista, function (i, o) {
                html += '<label><input type="checkbox" class="codApagar" value="' + o.codProdLoja + '"> ' + o.fabricante + ' ' + o.modelo + ' (R$ ' + o.preco + ')</label><br/>';
            });
            $('#tabela-produtos-desativados').html(html);

            $('#btn-selecionar-todos-inativos').show();
            $('#btn-deselecionar-todos-inativos').hide();

            $('#modalConfirmaExcluir').modal('show');
        });

        return false;
    });

    $('#btn-apagar-inativos').click(function () {
        var lista = [];
        $('input[type=checkbox].codApagar:checked').each(function () {
            lista.push(parseInt($(this).val()));
        });

        if (lista.length < 1) {
            alert('Nenhum produto selecionado!');
            return false;   // Nenhum produto selecionado!!!
        }

        $.ajax({
            type: 'POST',
            url: 'limpar-desativados',
            data: JSON.stringify(lista),
            contentType: 'application/json; charset=utf-8',
            success: function (status) {
                if (status != 'ok')
                    alert(status);
                window.location.reload();
            },
            failure: function (errMsg) {
                alert(errMsg);
                window.location.reload();
            }
        });

        return false;
    });

    $('#btn-selecionar-todos-inativos').click(function () {
        $('div#tabela-produtos-desativados input[type=checkbox].codApagar').prop('checked', true);
        $('#btn-selecionar-todos-inativos').hide();
        $('#btn-deselecionar-todos-inativos').show();
        return false;
    });

    $('#btn-deselecionar-todos-inativos').click(function () {
        $('div#tabela-produtos-desativados input[type=checkbox].codApagar').prop('checked', false);
        $('#btn-selecionar-todos-inativos').show();
        $('#btn-deselecionar-todos-inativos').hide();
        return false;
    });

    $('#btn-condensar').click(function (e) {

        if (tabela.$('span.especificacao.expandida').length > 0) {
            tabela.$('span.especificacao.expandida').removeClass('expandida').addClass('compacta');
            $('#icon-condensar').removeClass('fa-compress').addClass('fa-expand').prop('title', 'Expandir especificação');
            compacta = true;
            setCookie('RevendaCadastroProdutosCompacta', 1, 365);
        }
        else {
            tabela.$('span.especificacao.compacta').removeClass('compacta').addClass('expandida');
            $('#icon-condensar').removeClass('fa-expand').addClass('fa-compress').prop('title', 'Condensar especificação');
            compacta = false;
            deleteCookie('RevendaCadastroProdutosCompacta');
        }

        e.preventDefault();
        e.stopPropagation();
        return false;
    });

    $('#aviso-ack').change(function () {
        if ($(this).prop('checked')) {
            var id = $(this).val();
            $.get('ackaviso/' + id, function (status) {
                if (status == 'ok')
                    $('#modalAviso').modal('toggle');
                else
                    alert(status);
            });
        }
    });
});
