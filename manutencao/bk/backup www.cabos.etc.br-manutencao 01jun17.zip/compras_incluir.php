<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Compras - Incluir</title>
</head>
<link href="../lojas.css" rel="stylesheet" type="text/css" />
<body>

<SCRIPT language="JavaScript">
function muda_cdproduto(varcdproduto){

document.getElementById("cdproduto1").value=varcdproduto;
varfonte_imagem="../imagens/produtos//"+varcdproduto+".jpg";
//alert(varfonte_imagem);	
document.getElementById("imagem_produto1").src=varfonte_imagem;

return;
}

function troca_imagem_produto(varimagem){
	varcdproduto=document.getElementById("cdproduto").value;
	varfonte_imagem="../imagens/produtos//"+varcdproduto+".jpg";
	//alert(varfonte_imagem);	
	document.getElementById("imagem_produto").src=varfonte_imagem;
}


</script>


<?
//Prepara conexao ao db
include("../conectadb.php");
?>

<?
// Busca o codigo da Loja
$ponteiro = fopen ("../loja.txt", "r");
while (!feof ($ponteiro)) {
  $linha = fgets($ponteiro, 4096);
  $cdloja=$linha;

}
fclose ($ponteiro);

$query="SELECT nomeloja FROM lojas WHERE cdloja='".$cdloja."'";
$resultado = mysql_query($query,$conexao);
$nomeloja=mysql_result($resultado,0,0);

?>


<? include("../manutencao/menu.php");?>
<table width="960" border="0" align="center">
  <tr>
    <td><h3><br />
      Inclus&atilde;o de compras no sistema </h3>
<?

$cdproduto=$_REQUEST["cdproduto"];

$hoje=date("d/m/Y",strtotime("now")); 
$query="SELECT cotacao_us FROM parametros";
$resultado = mysql_query($query,$conexao);
$cotacao_us=mysql_result($resultado,0,0);
?>
<form action="compras_rotinas.php" method="get">
<table width="960" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Data da compra</td>
    <td><input name="dtcompra" type="text" id="dtcompra" maxlength="10" value="<? echo $hoje;?>" /></td>
    <td>&nbsp;</td>
    <td>Status</td>
    <td><input name="cdstatus" type="text" id="cdstatus" value="0" size="5" maxlength="1"/></td>
  </tr>
  </table>
  
  <table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><h3>Itens comprados</h3></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>Moeda 
      <label for="moeda"></label>
      <select name="moeda" id="moeda">
        <option value="1">Real</option>
        <option value="2" selected="selected">Dolar</option>
      </select></td>
  </tr>
  <tr>
    <td>C&oacute;digo do Produto</td>
    <td>&nbsp;</td>
    <td>Imagem</td>
    <td>Quantidade</td>
    <td>Custo do lote</td>
  </tr>
  <tr>
    <td><input name="cdproduto1" type="text" id="cdproduto1" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png"  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" name="imagem_produto1" width="30" height="30" id="imagem_produto1" /></td>
    <td><input name="quantidade1" type="text" id="quantidade1" maxlength="5" /></td>
    <td><input name="custo_lote1" type="text" id="custo_lote1" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto2" type="text" id="cdproduto2" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto2" width="30" height="30" id="imagem_produto2" /></td>
    <td><input name="quantidade2" type="text" id="quantidade2" maxlength="5" /></td>
    <td><input name="custo_lote2" type="text" id="custo_lote2" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto3" type="text" id="cdproduto3" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto3" width="30" height="30" id="imagem_produto3" /></td>
    <td><input name="quantidade3" type="text" id="quantidade3" maxlength="5" /></td>
    <td><input name="custo_lote3" type="text" id="custo_lote3" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto4" type="text" id="cdproduto4" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto4" width="30" height="30" id="imagem_produto4" /></td>
    <td><input name="quantidade4" type="text" id="quantidade4" maxlength="5" /></td>
    <td><input name="custo_lote4" type="text" id="custo_lote4" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto5" type="text" id="cdproduto5" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto5" width="30" height="30" id="imagem_produto5" /></td>
    <td><input name="quantidade5" type="text" id="quantidade5" maxlength="5" /></td>
    <td><input name="custo_lote5" type="text" id="custo_lote5" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto6" type="text" id="cdproduto6" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto6" width="30" height="30" id="imagem_produto6" /></td>
    <td><input name="quantidade6" type="text" id="quantidade6" maxlength="5" /></td>
    <td><input name="custo_lote6" type="text" id="custo_lote6" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto7" type="text" id="cdproduto7" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto7" width="30" height="30" id="imagem_produto7" /></td>
    <td><input name="quantidade7" type="text" id="quantidade7" maxlength="5" /></td>
    <td><input name="custo_lote7" type="text" id="custo_lote7" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto8" type="text" id="cdproduto8" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto8" width="30" height="30" id="imagem_produto8" /></td>
    <td><input name="quantidade8" type="text" id="quantidade8" maxlength="5" /></td>
    <td><input name="custo_lote8" type="text" id="custo_lote8" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto9" type="text" id="cdproduto9" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto9" width="30" height="30" id="imagem_produto9" /></td>
    <td><input name="quantidade9" type="text" id="quantidade9" maxlength="5" /></td>
    <td><input name="custo_lote9" type="text" id="custo_lote9" maxlength="5" /></td>
  </tr>
  <tr>
    <td><input name="cdproduto10" type="text" id="cdproduto10" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/></td>
    <td><a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt=""  /></a></td>
    <td><img src="../imagens/produtos/00000.jpg" alt="" name="imagem_produto10" width="30" height="30" id="imagem_produto10" /></td>
    <td><input name="quantidade10" type="text" id="quantidade10" maxlength="5" /></td>
    <td><input name="custo_lote10" type="text" id="custo_lote10" maxlength="5" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="960" border="0" align="center">
  <tr>
    <td colspan="6"><h3>Dados do pagamento</h3></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="right">Nome do Fornecedor:</td>
    <td><input name="idpaypal" type="text" id="idpaypal" maxlength="15" /></td>
    <td align="right">Cart&atilde;o: </td>
    <td>
    <?
echo "<select name='cartao' id='cartao'>";
$query="SELECT  numero, descricao, vencimento FROM cartoes ORDER BY numero";
$resultado = mysql_query($query,$conexao);
	while ($row = mysql_fetch_array($resultado, MYSQL_NUM)) {
		$numero=$row[0]; 
		$descricao=$row[1]; // descricao
		$vencimento=$row[2]; // descricao
		echo "<option value='".$numero."'>".$numero."-".$descricao." [".$vencimento."]</option>";
}
echo "</select>";
?>
    </td>
    <td align="right">Cota&ccedil;&atilde;o do Dolar: </td>
    <td><input name="cotacao_us" type="text" id="cotacao_us" maxlength="5" value="<? echo $cotacao_us; ?>"/></td>
  </tr>
  <tr>
    <td align="right">Atalhos:</td>
    <td colspan="2"><input type="button" name="BIC" id="BIC" value="BIC" onclick="javascript:document.getElementById('idpaypal').value='BUYINCOINSC'" />
      <input type="button" name="BIC2" id="BIC2" value="TOM" onclick="javascript:document.getElementById('idpaypal').value='TOMTOPGROUP'" />
      <input type="button" name="BIC3" id="BIC3" value="GOL" onclick="javascript:document.getElementById('idpaypal').value='GOLDENBRIDGE'" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="right">Transportadora: </td>
    <td><?
echo "<select name='cdtransportadora' id='cdtransportadora'>";
$query="SELECT  cdtransportadora, nome FROM transportadoras ORDER BY nome";
$resultado = mysql_query($query,$conexao);
	while ($row = mysql_fetch_array($resultado, MYSQL_NUM)) {
		$cdtransportadora=$row[0]; 
		$nome=$row[1]; // descricao
		echo "<option value='".$cdtransportadora."'>".$nome."</option>";
}
echo "</select>";
?></td>
    <td align="right">Codigo de rastreamento: </td>
    <td><input name="cdrastreamento" type="text" id="cdrastreamento" maxlength="15" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="right">Observa&ccedil;&otilde;es: </td>
    <td colspan="4"><input name="observacao" type="text" id="observacao" size="60" maxlength="50" /></td>
    <td><input name="modo" type="hidden" id="modo" value="incluir" />
      <input name="cdloja" type="hidden" id="cdloja" value="<? echo $cdloja; ?>" /><input type="submit" name="Enviar" id="Enviar" value="Submit" /></td>
  </tr>
  </table>
<p>&nbsp;</p>
</form>

<?

$query2="SELECT favoritos.cdproduto,produtos.nome FROM favoritos,produtos where favoritos.cdproduto=produtos.cdproduto AND favoritos.cdloja='".$cdloja."' ORDER BY favoritos.cdproduto";
//echo $query2;
$resultado2 = mysql_query($query2,$conexao);

$cdproduto1=mysql_result($resultado2,0,0);
$cdproduto2=mysql_result($resultado2,1,0);
$cdproduto3=mysql_result($resultado2,2,0);
$cdproduto4=mysql_result($resultado2,3,0);
$cdproduto5=mysql_result($resultado2,4,0);
$cdproduto6=mysql_result($resultado2,5,0);
$cdproduto7=mysql_result($resultado2,6,0);
$cdproduto8=mysql_result($resultado2,7,0);
$cdproduto9=mysql_result($resultado2,8,0);
$cdproduto10=mysql_result($resultado2,9,0);
$cdproduto11=mysql_result($resultado2,10,0);
$cdproduto12=mysql_result($resultado2,11,0);
$cdproduto13=mysql_result($resultado2,12,0);
$cdproduto14=mysql_result($resultado2,13,0);
$cdproduto15=mysql_result($resultado2,14,0);
$cdproduto16=mysql_result($resultado2,15,0);

$nomeproduto1=mysql_result($resultado2,0,1);
$nomeproduto2=mysql_result($resultado2,1,1);
$nomeproduto3=mysql_result($resultado2,2,1);
$nomeproduto4=mysql_result($resultado2,3,1);
$nomeproduto5=mysql_result($resultado2,4,1);
$nomeproduto6=mysql_result($resultado2,5,1);
$nomeproduto7=mysql_result($resultado2,6,1);
$nomeproduto8=mysql_result($resultado2,7,1);
$nomeproduto9=mysql_result($resultado2,8,1);
$nomeproduto10=mysql_result($resultado2,9,1);
$nomeproduto11=mysql_result($resultado2,10,1);
$nomeproduto12=mysql_result($resultado2,11,1);
$nomeproduto13=mysql_result($resultado2,12,1);
$nomeproduto14=mysql_result($resultado2,13,1);
$nomeproduto15=mysql_result($resultado2,14,1);
$nomeproduto16=mysql_result($resultado2,15,1);

echo "<table width='900' border='0'>";
echo "<tr>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto1.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto1."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto2.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto2."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto3.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto3."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto4.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto4."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto5.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto5."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto6.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto6."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto7.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto7."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto8.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto8."')\"></td>";
echo "</tr>";
echo "<tr>";
echo "<td height='21' align='center'>".$nomeproduto1."</td>";
echo "<td height='21' align='center'>".$nomeproduto2."</td>";
echo "<td height='21' align='center'>".$nomeproduto3."</td>";
echo "<td height='21' align='center'>".$nomeproduto4."</td>";
echo "<td height='21' align='center'>".$nomeproduto5."</td>";
echo "<td height='21' align='center'>".$nomeproduto6."</td>";
echo "<td height='21' align='center'>".$nomeproduto7."</td>";
echo "<td height='21' align='center'>".$nomeproduto8."</td>";
echo "</tr>";

echo "<tr>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto9.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto9."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto10.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto10."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto11.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto11."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto12.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto12."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto13.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto13."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto14.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto14."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto15.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto15."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='../imagens/produtos/".$cdproduto16.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto16."')\"></td>";
echo "</tr>";
echo "<tr>";
echo "<td height='21' align='center'>".$nomeproduto9."</td>";
echo "<td height='21' align='center'>".$nomeproduto10."</td>";
echo "<td height='21' align='center'>".$nomeproduto11."</td>";
echo "<td height='21' align='center'>".$nomeproduto12."</td>";
echo "<td height='21' align='center'>".$nomeproduto13."</td>";
echo "<td height='21' align='center'>".$nomeproduto14."</td>";
echo "<td height='21' align='center'>".$nomeproduto15."</td>";
echo "<td height='21' align='center'>".$nomeproduto16."</td>";
echo "</tr>";
echo "</table>";

?>

</td>
  </tr>
</table> <!--Fim da tabela estrutural-->
</body>
</html>
