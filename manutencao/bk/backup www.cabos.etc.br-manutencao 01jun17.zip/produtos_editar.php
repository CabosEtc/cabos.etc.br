<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="X-UA-Compatible" content="IE=8" />
<link rel="image_src" href="" />

<!-- Conecta ao BD e busca codigo e nome da loja (disponivel em: $cdloja e $nomeloja) -->
<? include("../conectadb.php"); ?>

<meta name="description" content="<? echo "$index_description";?>" />
<meta name="keywords" content="<? echo "$index_keywords";?>" />
<meta name="robots" content="INDEX,FOLLOW" />
 
<title>Produtos editar</title>
<link href="../lojas_v2.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="java_bigdigital.js"></script>

<!-- Mensagem caso o Javascript esteja desabilitado -->
<noscript>
    <div class="noscript">
        <div class="noscript-inner">
            <p><strong>JavaScript seem to be disabled in your browser.</strong></p>
            <p>Voc� deve ter o JavaScript habilitado no seu navegador para usar as funcionalidades deste site.</p>
        </div>
    </div>
</noscript>

</head>


<body>


<!-- Corpo da pagina ---------------------------------------------------------->
<div class="pagina">

<? //include("topo_v2.php"); ?>
<? //include("menu_superior_v2.php"); ?>
<? //include("corpo_esquerda_v2.php"); ?>

<div class="corpo_direita">
<!-- Aqui come�a a area editavel ------------------------------------------------------->
  <?
$cdproduto=$_REQUEST["cdproduto"];
$modo=$_REQUEST["modo"];
$vlvenda=str_replace(",",".",$_REQUEST["vlvenda"]);
$vlvendasite=str_replace(",",".",$_REQUEST["vlvendasite"]);
$cdsubcategoria=$_REQUEST["cdsubcategoria"];
$vlcompra=str_replace(",",".",$_REQUEST["vlcompra"]);
$cdmoeda=$_REQUEST["cdmoeda"];
$idpreco=$_REQUEST["idpreco"];
$peso=$_REQUEST["peso"];
$descricao=$_REQUEST["descricao"];
$caracteristicas=$_REQUEST["caracteristicas"];
$ativo=$_REQUEST["ativo"];
$siteflag=$_REQUEST["siteflag"];
$estoque_minimo=$_REQUEST["estoque_minimo"];

if ($modo=="alterar"){
	$query="UPDATE precos SET vlvenda='$vlvenda', vlvendasite='$vlvendasite', cdsubcategoria='$cdsubcategoria', vlcompra='$vlcompra', cdmoeda='$cdmoeda', ativo='$ativo', siteflag='$siteflag', quant_estoque_min='$estoque_minimo'  WHERE idpreco='$idpreco'";
	$resultado = mysql_query($query,$conexao);
	
	$query="SELECT cdproduto FROM precos WHERE idpreco='$idpreco'";
	$resultado = mysql_query($query,$conexao);
	$cdproduto=mysql_result($resultado,0,0);
	
	$query="UPDATE produtos SET peso=".$peso.", descricao='".$descricao."', caracteristicas='".$caracteristicas."' WHERE cdproduto='$cdproduto'";
	$resultado=	mysql_query($query,$conexao);
	//echo $query;
	}

$query="SELECT precos.idpreco, precos.cdproduto, precos.cdloja, precos.cdsubcategoria, precos.vlcompra, precos.cdmoeda, precos.vlvenda, precos.vlvendasite, precos.garantia, precos.multiplicador3x, precos.multiplicador6x, precos.multiplicador9x, precos.multiplicador12x, precos.ativo, precos.siteflag, produtos.nome, produtos.peso, produtos.descricao, produtos.caracteristicas FROM precos, produtos WHERE precos.cdproduto='".$cdproduto."'  AND precos.cdproduto=produtos.cdproduto AND precos.cdloja='".$cdloja."'";
//echo $query;

$resultado = mysql_query($query,$conexao);

$idpreco=mysql_result($resultado,0,0);
$cdproduto=mysql_result($resultado,0,1);
$cdloja=mysql_result($resultado,0,2); 	
$cdsubcategoria_produto=mysql_result($resultado,0,3);
$vlcompra=mysql_result($resultado,0,4); 	
$cdmoeda_produto=mysql_result($resultado,0,5); 	
$vlvenda=mysql_result($resultado,0,6);
$vlvendasite=mysql_result($resultado,0,7);
$garantia=mysql_result($resultado,0,8);
$multiplicador3x=mysql_result($resultado,0,9);
$multiplicador6x=mysql_result($resultado,0,10);
$multiplicador9x=mysql_result($resultado,0,11);
$multiplicador12x=mysql_result($resultado,0,12);
$ativo=mysql_result($resultado,0,13);
$siteflag=mysql_result($resultado,0,14);
$nomeproduto=mysql_result($resultado,0,15);
$peso=mysql_result($resultado,0,16);
$descricao=mysql_result($resultado,0,17);
$caracteristicas=mysql_result($resultado,0,18);

?>
<div id="topo" style="background:repeat url(../imagens/xc_stripes.gif); height:200px;"><img src="../imagens/tools.gif" width="48" height="48" />Novo Menu</div>
  <img src="<? echo $caminho_imagens.$cdproduto; ?>.jpg" width="150" height="150" /> 
  
 <form name="form_editar_produto" id="form_editar_produto" action="produtos_editar.php">
<div> C�digo: <? echo $cdproduto; ?></div>
<div style="padding-bottom:30px;"> Nome: <? echo $nomeproduto; ?></div>

<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Pre�o na loja:</label><input name="vlvenda" id="vlvenda" type="text" value="<? echo $vlvenda;?>" /></div>

<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Pre�o no site:</label>
<input name="vlvendasite" id="vlvendasite" type="text" value="<? echo $vlvendasite; ?>" /></div>
  
<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Subcategoria:</label>
<select name="cdsubcategoria">
<?
// Busca as subcategorias cadastradas para esta loja
$query2="SELECT cdsubcategoria, cdcategoria, descricao FROM subcategoria WHERE cdloja = '".$cdloja."' ORDER BY descricao ASC";
	
	echo $query2;
	$resultado2 = mysql_query($query2,$conexao);
	
	while ($row = mysql_fetch_array($resultado2, MYSQL_NUM)) {
		$cdsubcategoria=$row[0]; // nome da categoria
		$cdcategoria=$row[1]; // nome da categoria
		$descricao_categoria=$row[2]; // nome da categoria
		if($cdsubcategoria==$cdsubcategoria_produto){
			$selecionado="selected=\"selected\"";
			}
			else {
				$selecionado="";
				}
	    echo "<option value='".$cdsubcategoria."' ".$selecionado.">".$descricao_categoria." (".$cdsubcategoria.")"."</option>";
		}
?>
 </select>
 </div>
 
<input name="modo" type="hidden" value="alterar" />
<input name="cdproduto" type="hidden" value="<? echo $cdproduto; ?>" />
<input name="idpreco" type="hidden" value="<? echo $idpreco; ?>" />

<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Valor de compra</label>
<input name="vlcompra" id="vlcompra" type="text" value="<? echo $vlcompra; ?>" /></div>

<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Moeda de compra:</label>
<select name="cdmoeda">
<?
// Busca as subcategorias cadastradas para esta loja
$query3="SELECT cdmoeda FROM moedas";
	
	//echo $query3;
	$resultado3 = mysql_query($query3,$conexao);
	
	while ($row = mysql_fetch_array($resultado3, MYSQL_NUM)) {
		$cdmoeda=$row[0]; // nome da categoria
		if($cdmoeda==$cdmoeda_produto){
			$selecionado="selected=\"selected\"";
			}
			else {
				$selecionado="";
				}
	    echo "<option value='".$cdmoeda."' ".$selecionado.">".$cdmoeda."</option>";
		}
?>
 </select>
 </div>

<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Peso do produto:</label>
<input name="peso" id="peso" type="text" value="<? echo $peso; ?>" /></div>

<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Ativo na loja:</label>
<input name="ativo" type="text" id="ativo" value="<? echo $ativo; ?>" size="10" maxlength="1" />0-Nao 1-Sim</div>
<div style="clear:both;"></div>

<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Ativo no site:</label>
<input name="siteflag" type="text" id="siteflag" value="<? echo $siteflag; ?>" size="10" />0-Nao 1-Sim</div>
<div style="padding:5px;"><label style="width:200px; float:left; display:block;">Quantidade m�nima em estoque:</label>
<input name="estoque_minimo" type="text" id="estoque_minimo" value="<? echo $estoque_minimo; ?>" size="6" /></div>

<div style="padding-top:20px; padding-bottom:20px">
 <div style="float:left; position:relative;"> Descricao:</div>
<div style="position:fixed; margin-left:200px;"> 
 <textarea name="descricao" cols="120" rows="5" id="descricao" type="text" /><? echo $descricao; ?></textarea>
</div>
</div>
<div style="clear:both;"></div>

<div style="padding-top:100px; padding-bottom:20px">
<div  style="position:relative;"> Caracteristicas:</div>
<div style="position:relative; margin-left:200px;"><textarea name="caracteristicas" cols="120" rows="5" id="caracteristicas" type="text" /><? echo $caracteristicas; ?></textarea>
</div>
</div>
 <div style="clear:both;"></div>

 <div style="padding:5px;">Nota: Come�ar a descricao e as caracteristicas sempre com este nota��o &lt;lu&gt; &lt;li&gt;Linha 1&lt;/li&gt;&lt;li&gt;Linha 2&lt;/li&gt;&lt;/lu&gt;, &eacute; isto que coloca o ponto no inicio do texto.</div>
<div style="padding-left:620px;"> <input name="Alterar" type="submit" value="Alterar" /></div>

 </form> 
   <!-- Aqui termina a area editavel -------------------------------------------------->
  </div>
      <div style="clear:both;"></div>

<? //include("rodape_v2.php"); ?>
</div>
 <!-- final da div pagina----------------------------------------------------------->

</body>
</html>
