<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="../lojas.css" rel="stylesheet" type="text/css" />
<?
//Prepara conexao ao db
include("../conectadb.php");
?>

<?
// Busca o codigo da Loja
$ponteiro = fopen ("../loja.txt", "r");
while (!feof ($ponteiro)) {
  $linha = fgets($ponteiro, 4096);
  $cdloja=$linha;

}
fclose ($ponteiro);

$query="SELECT nomeloja FROM lojas WHERE cdloja='".$cdloja."'";
$resultado = mysql_query($query,$conexao);
$nomeloja=mysql_result($resultado,0,0);

?>
<?
session_start();

$modo=$_REQUEST['modo'];
$usuario=$_REQUEST['usuario'];
$senha=$_REQUEST['senha'];

if ($modo=="logoff"){
unset($_SESSION['usuario']);
unset($_SESSION['senha']);
echo "<meta http-equiv='refresh' content='0; url=index.php'>";
}

if ($modo=="logon"){
	
	//Filtra pela cidade origem fornecida
	$query = "select usuario, senha, nivel, email FROM usuarios WHERE usuario='".$usuario."' AND senha='".$senha."' AND cdloja='".$cdloja."'";
	$resultado = mysql_query($query,$conexao);
	$total=mysql_num_rows($resultado);
	if ($total==1){
	$_SESSION['usuario']=$usuario;
	$_SESSION['senha']=$senha;
	$_SESSION['nivel']=mysql_result($resultado,0,2);
	$email_usuario=mysql_result($resultado,0,3);
	//echo $email_usuario;
	
	// Inclui a informa��o de login no arquivo log // codigo 500=login
	$dthoje=date("Y-m-d",strtotime("now"));
	$hora_atual=strftime("%H:%M",strtotime("now"));
	$query_login="INSERT INTO log(idlog, data, loja, codigo, inf1, inf2, inf3, inf4) VALUES ('null', '$dthoje', '$cdloja', '500', '$hora_atual', '$usuario','null', 'null')"; 
	//echo $query_login;
	$resultado_login = mysql_query($query_login,$conexao);
	
	// Rotinas de email: ---------------------------------------------------------------------------------------------------------------------------------

//  Manda o email para o vendedor, confirmando seu login no sistema

		$emaildestino=$email_usuario;

	// D� titulo ao email
		$emailassunto="Controle de acesso - ".$nomeloja; 
		
	
// Inicio da montagem do texto da mensagem

		# HTML Version 

		$msg = "
		<html>
		<body><p>"
		// texto aqui //
		
		."O login do usu�rio ".$email_usuario." foi realizado com sucesso em: ".$dthoje.", as ".$hora_atual."</p>"."	</body>
		</html>";

	// rotina de envio do email ** comum a todos **
	//define os headers de envio 
	//$headers.= "From:".$contato." <".$email.">\nContent-type: text/html"; ;
	//$headers.="From: ".$email."\nContent-type: text/html";   
    //$headers .= "Reply-To: \"$email\"\n"; 

$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers = "From: ".$nome_loja." <".$emaildestino.">\r\n"; // deve ser configurado emaildestino aqui para evitar que filtros spam bloqueiem a mensagem, a linha return-path faz com que o reply siga para quem esta enviando a mensagem. 
$headers .= "Reply-To: ".$nome_loja." <".$emaildestino.">\r\n";
// adicionado para enviar copia para Suellen
$headers .= "Cc: mail.f.grande@gmail.com" . "\r\n"; 

// confirmar sintaxe deste abaixo
$headers .= "Return-Path: ".$nome_loja." <".$emaildestino.">\r\n"; 

$headers .= "Content-Type: text/HTML\r\n"; 
//mail($email,$msg_assunto,$mensagem,$cabecalho) 

// envia o email para a filial escolhida
// a linha de baixo acrescenta texto a msg confeccionada acima, para que o texto de resposta j� fique incluido no email da filial, evitando digita��o desnecessaria.

	if (mail($emaildestino, $emailassunto, $msg, $headers))
{ // se o email pode ser enviado
		//echo "Sua mensagem foi enviada para ".$emaildestino."<p>";
//		echo "Voc� retornar� a p�gina inicial em 10 segundos, caso n�o retorne clique <a href='javascript:history.go(-1)'>aqui</a></p>"; 
	}
 	else {
		// echo "Ocorreu um erro durante o envio do email.";
	}

// ------------------------------------------------------------------------------------


	
	echo "<meta http-equiv='refresh' content='1; url=../manutencao/index.php'>";
	}
	else {
		echo "<meta http-equiv='refresh' content='0; url=../manutencao/login.php'>";
		}
}
?>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Manuten&ccedil;&atilde;o</title>
</head>
<link href="../cabos.css" rel="stylesheet" type="text/css" />
<body>
<? include("../manutencao/menu.php");?>
<br />
<table width="960" border="0" align="center">
  <tr>
    <td><h3>&nbsp;</h3></td>
  </tr>
  <tr>
    <td height="300">
    <form id="form1" name="form1" method="post" action="../manutencao/login.php">
    <table width="300" border="0" align="center">
      <tr>
        <td colspan="2"><? if(!isset($_SESSION["usuario"])) {echo"<Senha incorreta, tente novamente por favor.";} ?></td>
        </tr>
      <tr>
        <td width="150">Login:
          
          </td>
        <td><label>
          <input type="text" name="usuario" id="usuario" />
        </label></td>
      </tr>
      <tr>
        <td>Senha:</td>
        <td><label>
          <input type="password" name="senha" id="senha" />
        </label></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><input name="modo" type="hidden" id="modo" value="logon" /></td>
        <td><label>
          <input type="submit" name="Enviar" id="Enviar" value="Enviar" />
        </label></td>
      </tr>
    </table>
    </form></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;	</p>
</body>

</html>
