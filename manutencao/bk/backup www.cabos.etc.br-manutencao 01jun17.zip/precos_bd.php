<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Precos BD</title>


<script type="text/javascript">
  //20 minutos = 1200 Segundos
  var t=1200;
  

  function timedCount()
  {
    if(t>0)
    {
	  document.getElementById("txt").innerHTML = "Faltam: " + t + " segundos para refresh da pagina.";
      setTimeout("timedCount()", 1000);
	  t=t-1;
	 }	
	 
	 if(t==0)
	 {
	  location.href = "http://www.cabos.etc.br/manutencao/precos_bd.php";
	}
  }
</script>



</head>

<!-- Este comentario desabilita o contator provisoriamente (por causa da rotina cron no servidor, em advanced, cron server)
<body onload='timedCount()'>
-->

<body>

<div id="txt">Texto</div>

<?

session_start();
//if (!isset($_SESSION["usuario"])){
//			echo "<meta http-equiv='refresh' content='0; url=../manutencao/login.php'>";
//	}

//Prepara conexao ao db
include("../conectadb.php");

// Busca o codigo da Loja
$ponteiro = fopen ("../loja.txt", "r");
while (!feof ($ponteiro)) {
  $linha = fgets($ponteiro, 4096);
  $cdloja=$linha;

}
fclose ($ponteiro);

$dthoje_eua=date("Y-m-d",strtotime("now"));
$hora=date("h:i:s",strtotime("now"));

$query="SELECT nomeloja FROM lojas WHERE cdloja='".$cdloja."'";
$resultado = mysql_query($query,$conexao);
$nomeloja=mysql_result($resultado,0,0);


echo "<br>";
//echo "<table width='960' align='center'><tr><td>"; // tabela estrutural externa



echo "<h3>Relat�rio de precos do Boadica (".$hora.")</h3><br>";

$cdproduto=$_REQUEST["cdproduto"];
$modo=$_REQUEST["modo"];
//if ($_SESSION["nivel"]<3){
//			echo "<meta http-equiv='refresh' content='0; url=../manutencao/mensagem.php?cdmensagem=1'>";
//	}
// permite que pagina externas sejam lidas
ini_set('allow_url_fopen', 1);

// seleciona os produtos no banco de dados links_boadica

// Escreve todas as categorias no inicio da pagina com link

IF ($cdproduto<>""){
	$query="SELECT id, produto, link from links_boadica WHERE cdproduto='$cdproduto'  ORDER BY produto";
} ELSE {
	$query="SELECT id, produto, link from links_boadica ORDER BY produto";
		}

$resultado = mysql_query($query,$conexao);
while ($row = mysql_fetch_array($resultado, MYSQL_NUM)) {
	$id=$row[0]; 
	$produto=$row[1]; 
	$link=$row[2];
	
	
	echo "<h3>".$produto."</h3> ";
	
	$pagina=file_get_contents($link);
	$inicio=strpos($pagina,"<div class=\"loja\">");
	//echo $inicio;
	$fim=strrpos($pagina,"<div id=\"div-detalhes\">");
	//echo $fim;
	$tamanho=$fim-$inicio;
	$dados_novos=addslashes(substr($pagina,$inicio,$tamanho));
	
	$findme="Cabos e etc";
			$flag=strpos($dados_novos,$findme);
			IF ($flag === false){ // Se n�o achar nosso anuncio
				echo "<font color='red'>**Anuncio Desativado!!!!!**</font><br>";
				$query_flag_ativo="UPDATE links_boadica SET flag_ativo='0' WHERE id ='$id'";
				$resultado_flag_ativo = mysql_query($query_flag_ativo,$conexao);
				// echo $query_flag_ativo;
			} 			ELSE { // Se achar nosso anuncio
				$query_flag_ativo="UPDATE links_boadica SET flag_ativo='1' WHERE id ='$id'";
				$resultado_flag_ativo = mysql_query($query_flag_ativo,$conexao);
				// echo $query_flag_ativo;
			}
			
			echo "<a href='".$link."' TARGET='_blank'>Visitar link</a><BR><BR>";	
	
	
	$linhas_dados = preg_split("/\n/", substr($pagina,$inicio,$tamanho));
	
	
	foreach ($linhas_dados as $field) {		
	$inicio_nome=strpos($field,"target")+16;
	$fim_nome=strrpos($field,"</a>");
	$tamanho_nome=$fim_nome-$inicio_nome;
	$nome_loja=substr($field,$inicio_nome,$tamanho_nome);
	
	
	
	
	if (strpos($field,"target")){
		
				$query_id="SELECT id_loja, flag_predio from lojas_boadica WHERE nome='".$nome_loja."'";
		$resultado_id = mysql_query($query_id,$conexao);
		if(mysql_num_rows($resultado_id)>0){
		$id_loja=mysql_result($resultado_id,0,0);
		$flag_predio=mysql_result($resultado_id,0,1);
		//echo "id da loja=".$id_loja."<br>";
		
		$flag_loja_cadastrada=1;
		
		} else {
			echo "** Loja n�o cadastrada no BD";}
			$flag_loja_cadastrada=0;
			
		// Pesquisa ultima altera��o de pre�os
		$query_ultima_alteracao="SELECT data from links_boadica_detalhes_lojas WHERE id_loja='".$id_loja."' AND id_produto='".$id."' ORDER BY data DESC";
		$resultado_ultima_alteracao = mysql_query($query_ultima_alteracao,$conexao);
		
		if(mysql_num_rows($resultado_ultima_alteracao)>0){
		$data_ultima_alteracao=mysql_result($resultado_ultima_alteracao,0,0);
		} 	
		$data_ultima_alteracao=substr($data_ultima_alteracao,0,10);
		
		IF ($data_ultima_alteracao==$dthoje_eua){
			ECHO "<img src='../imagens/check.gif' width='16' height='16' />";
			}
		
		if ($flag_predio==0){
		echo "<font color='#FFA500'>".$nome_loja,"</font><br>";
		}
		if ($flag_predio==1){
		echo "<font color='#FF0000'>".$nome_loja,"</font><br>";
		}if ($flag_predio==2){
		echo "<font color='#0000FF'>".$nome_loja,"</font><br>";
		}
		
		
		
		
		
		
		
	} // fim do FOR EACH
	
	// echo $nome_loja;
	
	$inicio_preco=strpos($field,"R$ ");
	$fim_preco=strrpos($field,"\n");
	//$tamanho_preco=$fim_preco-$inicio_preco;
	$preco=floatval(str_replace(",",".",substr($field,$inicio_preco+3,10)));
	$preco=number_format((float)$preco, 2, '.', '');
		if (strpos($field,"R$")){
		echo "preco:".$preco;
		
		// ********************** 	FAZER PESQUISA, GUARDAR S� SE RESULTADO FOR DIFERENTE DO ULTIMO!!!!
		
		$query_pesquisa_preco_antigo="SELECT preco, data FROM links_boadica_detalhes_lojas WHERE id_loja='$id_loja' AND id_produto='$id' ORDER BY data DESC";
		$resultado_pesquisa_preco_antigo = mysql_query($query_pesquisa_preco_antigo,$conexao);
		//ECHO $query_pesquisa_preco_antigo;
		if(mysql_num_rows($resultado_pesquisa_preco_antigo)>0){
				$preco_anterior=mysql_result($resultado_pesquisa_preco_antigo,0,0);
				$data_preco_anterior=mysql_result($resultado_pesquisa_preco_antigo,0,1);
			IF ($preco_anterior<>$preco){
				echo "  Preco anterior: ".$preco_anterior. " [".$data_preco_anterior."]<br>";
			}
				else {echo "<br>";}
		}
			$quantidade_itens=mysql_num_rows($resultado_pesquisa_preco_antigo);
			IF (($quantidade_itens=0 OR $preco_anterior<>$preco) AND $flag_loja_cadastrada=1){				
			$query_precos="INSERT INTO links_boadica_detalhes_lojas (`id`, `id_loja`, `data`, `id_produto`, `preco`) VALUES (NULL, $id_loja, NULL, $id, $preco);";
			$resultado_precos = mysql_query($query_precos,$conexao);
			}


		
		}
	
	
			
		

/*		
	if ($flag_predio=1){
				echo "<font color='#FF0000'>".$nome_loja."</font><br>";
				} else {
					echo "<font color='#FFFF00'>".$nome_loja."</font><br>";
					}
				echo $preco."<br>";		
*/				
		
		}
	
	
	
	/*
	$posicao_inicial_nome=strpos($dados_novos, 'target=\"_blank\">'); // inicio do nome da loja
	$posicao_final_nome=strpos($dados_novos, '</a>'); // fim do nome da loja
	$tamanho_nome_loja=$posicao_final_nome-$posicao_inicial_nome;
	$nome_loja=substr($dados_novos,$posicao_inicial_nome,$tamanho_nome_loja);
	echo $nome_loja;
	*/
	
	
	
	

/*	todo este trecho foi suspenso, verificar se ele realmente n�o � mais util (a compara��o � individual agora, n�o pelo md5 da pagina)
	
	$md5_novo=md5($dados_novos);

		$query_compara_md5="SELECT md5 from links_boadica_detalhes WHERE links_boadica_detalhes.id=".$id." ORDER BY sequencial DESC";
		echo $query_compara_md5;
		$resultado_md5 = mysql_query($query_compara_md5,$conexao);
		$md5_antigo=mysql_result($resultado_md5,0,0);
		echo $md5_antigo;

			//echo $produto;
			
			echo "<BR>";
		IF ($md5_novo<>$md5_antigo){
			echo "<font color='#3AFF00'> Foi modificado!!!!!</font> <BR>";
			//echo $dados_novos."<BR>";
			
			$query_inserir="INSERT INTO links_boadica_detalhes(`id`, `dados`, `md5`) VALUES ($id, '$dados_novos', '$md5_novo')";
//			$resultado2 = mysql_query($query_inserir,$conexao);
		}
			//Else {
				
			
			//}
				
				
*/
	
	
	
}
echo "<br><a href='precos_bd_dia.php' TARGET='_blank'>Link para alteracoes do dia</a>";

  // envia email avisando da atualiza��o
    $emailenviar = "mail.f.grande@gmail.com";
    $destino = $emailenviar;
    $assunto = "Contato pelo Site";
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From: $nome <$email>';
	
	$mensagem="teste";
     
    $enviaremail = mail($destino, $assunto, $mensagem, $headers);
    if($enviaremail){
    $mgm = "E-MAIL ENVIADO COM SUCESSO! <br> O link ser� enviado para o e-mail fornecido no formul�rio";
    echo " Arquivo enviado";
    } else {
    echo "ERRO AO ENVIAR E-MAIL!";
    echo "";
    }


?>




</body>
</html>
