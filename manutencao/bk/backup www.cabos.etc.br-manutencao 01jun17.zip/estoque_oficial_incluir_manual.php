<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Compras - Incluir</title>
</head>
<link href="../lojas.css" rel="stylesheet" type="text/css" />
<body>

<SCRIPT language="JavaScript">
function muda_cdproduto(varcdproduto){

document.getElementById("cdproduto").value=varcdproduto;
varfonte_imagem="http://www.companhiadoscabos.com.br/imagens/produtos//"+varcdproduto+".jpg";
//alert(varfonte_imagem);	
document.getElementById("imagem_produto").src=varfonte_imagem;

return;
}

function troca_imagem_produto(varimagem){
	varcdproduto=document.getElementById("cdproduto").value;
	varfonte_imagem="http://www.companhiadoscabos.com.br/imagens/produtos//"+varcdproduto+".jpg";
	//alert(varfonte_imagem);	
	document.getElementById("imagem_produto").src=varfonte_imagem;
}


</script>

<h3>

<?
//Prepara conexao ao db
include("../conectadb.php");
?>

<?
// Busca o codigo da Loja
$ponteiro = fopen ("../loja.txt", "r");
while (!feof ($ponteiro)) {
  $linha = fgets($ponteiro, 4096);
  $cdloja=$linha;

}
fclose ($ponteiro);

$query="SELECT nomeloja FROM lojas WHERE cdloja='".$cdloja."'";
$resultado = mysql_query($query,$conexao);
$nomeloja=mysql_result($resultado,0,0);

?>
<?
include("../manutencao/menu.php");
$hoje=date("d/m/Y",strtotime("now")); 
$cdproduto=$_REQUEST["cdproduto"];

?>
  <br />
</h3>
<table width="960" border="0" align="center">
  <tr>
    <td><h3>Inclus�o de produtos no estoque oficial (Notas de entrada outros fornecedores  e importa&ccedil;&otilde;es)<br />
      <br />
    </h3>
    
<form action="estoque_oficial_rotinas.php" method="get">
  <table width="600" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Codigo do Produto</td>
    <td><input name="cdproduto" type="text" id="cdproduto" maxlength="5" value="<? echo $cdproduto;?>" onblur="troca_imagem_produto();"/>
      <a href="#" onclick="window.open('estoque_pesquisar_produto.php','popup','resizable=no,status=no,scrollbars=no,width=500,height=400,top=30,left=20')"><img src="../imagens/lupa.png" alt="" /></a></td>
    <td><img src="http://www.companhiadoscabos.com.br/imagens/produtos/00000.jpg" name="imagem_produto" width="150" height="150" id="imagem_produto" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Data da entrada</td>
    <td><input name="dtentrada" type="text" id="dtentrada" maxlength="10" <? echo "value='".$hoje."'";?> ></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Quantidade</td>
    <td><input name="quantidade" type="text" id="quantidade" maxlength="5"/></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Dados da nota</td>
    <td><input name="dados_nota" type="text" id="dados_nota" maxlength="30"/></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="modo" type="hidden" id="modo" value="incluir_manual" />      <input type="submit" name="Enviar" id="Enviar" value="Submit" /></td>
    <td>&nbsp;</td>
  </tr>
</table>
</form>



<?

$query2="SELECT favoritos.cdproduto,produtos.nome FROM favoritos,produtos where favoritos.cdproduto=produtos.cdproduto AND favoritos.cdloja='".$cdloja."' ORDER BY favoritos.cdproduto";
//echo $query2;
$resultado2 = mysql_query($query2,$conexao);

$cdproduto1=mysql_result($resultado2,0,0);
$cdproduto2=mysql_result($resultado2,1,0);
$cdproduto3=mysql_result($resultado2,2,0);
$cdproduto4=mysql_result($resultado2,3,0);
$cdproduto5=mysql_result($resultado2,4,0);
$cdproduto6=mysql_result($resultado2,5,0);
$cdproduto7=mysql_result($resultado2,6,0);
$cdproduto8=mysql_result($resultado2,7,0);
$cdproduto9=mysql_result($resultado2,8,0);
$cdproduto10=mysql_result($resultado2,9,0);
$cdproduto11=mysql_result($resultado2,10,0);
$cdproduto12=mysql_result($resultado2,11,0);
$cdproduto13=mysql_result($resultado2,12,0);
$cdproduto14=mysql_result($resultado2,13,0);
$cdproduto15=mysql_result($resultado2,14,0);
$cdproduto16=mysql_result($resultado2,15,0);

$nomeproduto1=mysql_result($resultado2,0,1);
$nomeproduto2=mysql_result($resultado2,1,1);
$nomeproduto3=mysql_result($resultado2,2,1);
$nomeproduto4=mysql_result($resultado2,3,1);
$nomeproduto5=mysql_result($resultado2,4,1);
$nomeproduto6=mysql_result($resultado2,5,1);
$nomeproduto7=mysql_result($resultado2,6,1);
$nomeproduto8=mysql_result($resultado2,7,1);
$nomeproduto9=mysql_result($resultado2,8,1);
$nomeproduto10=mysql_result($resultado2,9,1);
$nomeproduto11=mysql_result($resultado2,10,1);
$nomeproduto12=mysql_result($resultado2,11,1);
$nomeproduto13=mysql_result($resultado2,12,1);
$nomeproduto14=mysql_result($resultado2,13,1);
$nomeproduto15=mysql_result($resultado2,14,1);
$nomeproduto16=mysql_result($resultado2,15,1);

echo "<table width='900' border='0'>";
echo "<tr>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto1.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto1."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto2.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto2."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto3.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto3."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto4.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto4."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto5.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto5."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto6.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto6."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto7.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto7."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto8.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto8."')\"></td>";
echo "</tr>";
echo "<tr>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto1."')\">".$nomeproduto1."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto2."')\">".$nomeproduto2."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto3."')\">".$nomeproduto3."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto4."')\">".$nomeproduto4."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto5."')\">".$nomeproduto5."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto6."')\">".$nomeproduto6."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto7."')\">".$nomeproduto7."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto8."')\">".$nomeproduto8."</a></td>";
echo "</tr>";

echo "<tr>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto9.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto9."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto10.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto10."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto11.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto11."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto12.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto12."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto13.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto13."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto14.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto14."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto15.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto15."')\"></td>";
echo "<td width='100' align='center' valign='middle'><img src='http://www.companhiadoscabos.com.br/imagens/produtos/".$cdproduto16.".jpg' width='75' height='75' onclick=\"muda_cdproduto('".$cdproduto16."')\"></td>";
echo "</tr>";
echo "<tr>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto9."')\">".$nomeproduto9."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto10."')\">".$nomeproduto10."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto11."')\">".$nomeproduto11."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto12."')\">".$nomeproduto12."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto13."')\">".$nomeproduto13."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto14."')\">".$nomeproduto14."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto15."')\">".$nomeproduto15."</a></td>";
echo "<td height='21' align='center'><a href='#'  onclick=\"muda_cdproduto('".$cdproduto16."')\">".$nomeproduto16."</a></td>";
echo "</tr>";
echo "</table>";

?>




</td>
  </tr>
</table> <!-- fim da tabela exterior-->
</body>
</html>
